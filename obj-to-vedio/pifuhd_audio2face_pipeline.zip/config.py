"""
config.py
=========
Centralised configuration for the PIFuHD → Audio2Face pipeline.
Edit these values to tune each stage without touching pipeline logic.
"""

import os
from pathlib import Path

# ── Paths ──────────────────────────────────────────────────────────────────────
BASE_DIR    = Path(__file__).parent
ASSETS_DIR  = BASE_DIR / "assets"
OUTPUTS_DIR = BASE_DIR / "outputs"

# ── Mesh cleanup ───────────────────────────────────────────────────────────────
CLEANUP = dict(
    remove_duplicate_verts   = True,
    duplicate_threshold      = 1e-6,      # metres
    fix_normals              = True,
    fill_holes               = True,
    max_hole_size            = 500,       # max faces in a hole to fill
    decimate_face_count      = 15_000,   # target poly count after decimation
    decimate_preserve_border = True,
)

# ── Face detection ─────────────────────────────────────────────────────────────
FACE = dict(
    # Y-axis fraction of full mesh height where head begins
    head_y_fraction      = 0.72,
    # How far (fraction of head height) below top to look for chin
    chin_search_fraction = 0.40,
    # Face landmark model: "mediapipe" | "insightface" | "heuristic"
    landmark_backend     = "mediapipe",
    # Number of face landmarks to generate procedurally when no backend available
    procedural_landmarks = 468,
)

# ── Retopology ─────────────────────────────────────────────────────────────────
RETOPO = dict(
    target_verts      = 4_096,   # approximate vertex count for face region
    edge_loops_eyes   = 6,       # concentric loops around each eye
    edge_loops_mouth  = 8,       # concentric loops around mouth
    symmetry_axis     = "x",     # axis used to enforce left/right symmetry
)

# ── Blendshapes ────────────────────────────────────────────────────────────────
# Displacement magnitudes (in metres, relative to head bounding box)
BLENDSHAPE = dict(
    jaw_open_amount          = 0.04,
    smile_amount             = 0.025,
    pucker_amount            = 0.018,
    funnel_amount            = 0.016,
    blink_amount             = 0.008,
    brow_up_amount           = 0.012,
    brow_down_amount         = 0.010,
    cheek_puff_amount        = 0.015,
    viseme_aa_amount         = 0.035,
    viseme_oh_amount         = 0.028,
    viseme_ee_amount         = 0.022,
    viseme_fv_amount         = 0.014,
    viseme_mp_amount         = 0.006,
)

# Shape-key names must match Audio2Face ARKit convention
BLENDSHAPE_NAMES = [
    "JawOpen",
    "MouthSmileLeft",
    "MouthSmileRight",
    "EyeBlinkLeft",
    "EyeBlinkRight",
    "MouthPucker",
    "MouthFunnel",
    "BrowInnerUp",
    "BrowDown_L",
    "BrowDown_R",
    "CheekPuff",
    "Viseme_AA",
    "Viseme_OH",
    "Viseme_EE",
    "Viseme_FV",
    "Viseme_MP",
]

# ── Export ─────────────────────────────────────────────────────────────────────
EXPORT = dict(
    fbx_version     = "FBX202000",
    usd_extension   = ".usdc",           # .usdc (binary) or .usda (text)
    mesh_name       = "Head_Mesh",
    armature_name   = "Head_Armature",
    root_bone_name  = "Head",
)

# ── Lipsync / audio ────────────────────────────────────────────────────────────
LIPSYNC = dict(
    sample_rate       = 16_000,
    hop_length        = 512,
    n_mfcc            = 13,
    phoneme_model     = "heuristic",   # "heuristic" | "wav2vec2" (needs torch)
    smooth_window     = 3,             # frames to smooth blendshape curves
    fps               = 30,
)

# Phoneme → viseme mapping (ARKit subset)
PHONEME_VISEME_MAP = {
    # Vowels
    "AA": "Viseme_AA",  "AE": "Viseme_AA", "AH": "Viseme_AA",
    "AO": "Viseme_OH",  "AW": "Viseme_OH", "AY": "Viseme_AA",
    "EH": "Viseme_EE",  "ER": "Viseme_EE", "EY": "Viseme_EE",
    "IH": "Viseme_EE",  "IY": "Viseme_EE",
    "OW": "Viseme_OH",  "OY": "Viseme_OH",
    "UH": "Viseme_OH",  "UW": "Viseme_MP",
    # Bilabials
    "B":  "Viseme_MP",  "P": "Viseme_MP", "M": "Viseme_MP",
    # Labio-dentals
    "F":  "Viseme_FV",  "V": "Viseme_FV",
    # Misc / silence
    "SIL": "Viseme_MP",
}

# ── GPU ────────────────────────────────────────────────────────────────────────
GPU = dict(
    prefer_cuda = True,   # will fall back to CPU automatically
)

# ── Logging ────────────────────────────────────────────────────────────────────
LOG_LEVEL = "INFO"   # DEBUG | INFO | WARNING | ERROR
