"""
export.py
=========
Stage 6 — Audio2Face-ready export.

Supports:
  - FBX export (via Blender bpy)
  - USD export (via Blender bpy or usd-core)
  - Blendshape/shape-key injection into Blender scene
  - Audio2Face naming conventions
  - Headless Blender automation (no GUI needed)
"""

from __future__ import annotations
import argparse
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, Optional

import numpy as np

from config import BLENDSHAPE_NAMES, EXPORT, OUTPUTS_DIR
from utils.logger import get_logger

log = get_logger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────────────────────

def export_for_audio2face(
    mesh_path: str | Path,
    blendshape_dir: str | Path,
    output_dir: str | Path = OUTPUTS_DIR,
    formats: list[str] | None = None,
    blender_exec: str = "blender",
) -> Dict[str, Path]:
    """
    Drive Blender in headless mode to:
      1. Import the retopologised OBJ face mesh
      2. Inject all blendshapes as shape keys
      3. Add a minimal head armature
      4. Export as FBX and/or USD

    Parameters
    ----------
    mesh_path       : retopologised face OBJ
    blendshape_dir  : directory containing per-blendshape .npy files
    output_dir      : where to write exported files
    formats         : list of 'fbx' | 'usd' (default: both)
    blender_exec    : path to Blender executable

    Returns
    -------
    Dict mapping format string to output Path
    """
    if formats is None:
        formats = ["fbx", "usd"]

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Write a temporary Blender Python script
    script = _build_blender_script(
        mesh_path     = Path(mesh_path),
        blendshape_dir= Path(blendshape_dir),
        output_dir    = output_dir,
        formats       = formats,
    )

    script_path = output_dir / "_blender_export_script.py"
    script_path.write_text(script, encoding="utf-8")
    log.info(f"Blender export script written → {script_path}")

    result_paths = _run_blender(blender_exec, script_path, output_dir)
    return result_paths


# ─────────────────────────────────────────────────────────────────────────────
# Blender Python script builder
# ─────────────────────────────────────────────────────────────────────────────

def _build_blender_script(
    mesh_path: Path,
    blendshape_dir: Path,
    output_dir: Path,
    formats: list[str],
) -> str:
    """
    Build the complete Blender Python automation script as a string.
    This script is executed by Blender's embedded Python interpreter.
    """
    fbx_out = str(output_dir / "head_audio2face.fbx")
    usd_out = str(output_dir / "head_audio2face.usdc")
    mesh_name    = EXPORT["mesh_name"]
    armature_name = EXPORT["armature_name"]
    root_bone    = EXPORT["root_bone_name"]

    # Serialise blendshape names and dir for injection into the script string
    bs_names_json = json.dumps(BLENDSHAPE_NAMES)

    script = f'''
"""
Auto-generated Blender headless script.
Run via:  blender --background --python <this_file>
"""
import bpy
import bmesh
import numpy as np
import json
from pathlib import Path
from mathutils import Matrix, Vector

print("=== Audio2Face Blender Export Script ===")

# ── Constants ────────────────────────────────────────────────────────────────
MESH_PATH       = r"{mesh_path}"
BS_DIR          = Path(r"{blendshape_dir}")
FBX_OUT         = r"{fbx_out}"
USD_OUT         = r"{usd_out}"
MESH_NAME       = "{mesh_name}"
ARMATURE_NAME   = "{armature_name}"
ROOT_BONE_NAME  = "{root_bone}"
BS_NAMES        = {bs_names_json}
DO_FBX          = {"fbx" in formats}
DO_USD          = {"usd" in formats}

# ── 1. Clean default scene ────────────────────────────────────────────────────
bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)

# ── 2. Import OBJ ────────────────────────────────────────────────────────────
print(f"Importing OBJ: {{MESH_PATH}}")
if MESH_PATH.endswith(".obj"):
    bpy.ops.wm.obj_import(filepath=MESH_PATH)
else:
    raise RuntimeError(f"Unsupported mesh format: {{MESH_PATH}}")

# Get the imported mesh object
mesh_obj = None
for obj in bpy.context.scene.objects:
    if obj.type == "MESH":
        mesh_obj = obj
        break

if mesh_obj is None:
    raise RuntimeError("No mesh object found after import!")

mesh_obj.name      = MESH_NAME
mesh_obj.data.name = MESH_NAME + "_Data"
bpy.context.view_layer.objects.active = mesh_obj
print(f"Mesh: {{len(mesh_obj.data.vertices)}} verts, {{len(mesh_obj.data.polygons)}} faces")

# ── 3. Inject Shape Keys ──────────────────────────────────────────────────────
print("Injecting blendshapes as shape keys ...")

# Basis key
bpy.ops.object.shape_key_add(from_mix=False)
mesh_obj.data.shape_keys.key_blocks[0].name = "Basis"

basis_verts = np.array([v.co[:] for v in mesh_obj.data.vertices])

for bs_name in BS_NAMES:
    npy_path = BS_DIR / f"{{bs_name}}.npy"
    if not npy_path.exists():
        print(f"  WARNING: {{bs_name}}.npy not found — skipping")
        continue

    displaced = np.load(str(npy_path))
    if displaced.shape[0] != len(mesh_obj.data.vertices):
        print(f"  WARNING: {{bs_name}} vertex count mismatch — skipping")
        continue

    bpy.ops.object.shape_key_add(from_mix=False)
    sk = mesh_obj.data.shape_keys.key_blocks[-1]
    sk.name  = bs_name
    sk.value = 0.0

    # Apply displacements
    for i, coord in enumerate(displaced):
        sk.data[i].co = coord.tolist()

    print(f"  Shape key added: {{bs_name}}")

print(f"Total shape keys: {{len(mesh_obj.data.shape_keys.key_blocks)}}")

# ── 4. Create Head Armature ───────────────────────────────────────────────────
print("Creating head armature ...")

bpy.ops.object.armature_add(enter_editmode=True, location=(0, 0, 0))
arm_obj      = bpy.context.active_object
arm_obj.name = ARMATURE_NAME
arm          = arm_obj.data
arm.name     = ARMATURE_NAME + "_Data"

# Rename default bone to root
bone = arm.edit_bones[0]
bone.name   = ROOT_BONE_NAME
bb           = mesh_obj.bound_box
min_y = min(v[1] for v in bb)
max_y = max(v[1] for v in bb)
bone.head   = (0, min_y, 0)
bone.tail   = (0, max_y, 0)

bpy.ops.object.mode_set(mode="OBJECT")

# Parent mesh to armature
mesh_obj.select_set(True)
arm_obj.select_set(True)
bpy.context.view_layer.objects.active = arm_obj
bpy.ops.object.parent_set(type="ARMATURE_AUTO")

print("Armature created and mesh parented.")

# ── 5. Audio2Face metadata (custom properties) ────────────────────────────────
mesh_obj["audio2face_rig"]   = True
mesh_obj["blendshape_count"] = len(BS_NAMES)
mesh_obj["pipeline"]         = "pifuhd_audio2face"

# ── 6. Export FBX ─────────────────────────────────────────────────────────────
if DO_FBX:
    print(f"Exporting FBX → {{FBX_OUT}}")
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.export_scene.fbx(
        filepath            = FBX_OUT,
        use_selection       = False,
        use_mesh_modifiers  = True,
        add_leaf_bones      = False,
        bake_anim           = False,
        mesh_smooth_type    = "FACE",
        use_tspace          = True,
        use_custom_props    = True,
        path_mode           = "COPY",
        embed_textures      = True,
    )
    print("FBX export done.")

# ── 7. Export USD ─────────────────────────────────────────────────────────────
if DO_USD:
    print(f"Exporting USD → {{USD_OUT}}")
    try:
        bpy.ops.wm.usd_export(
            filepath               = USD_OUT,
            export_animation       = False,
            export_hair            = False,
            export_uvmaps          = True,
            export_normals         = True,
            export_materials       = True,
            use_instancing         = False,
            evaluation_mode        = "RENDER",
        )
        print("USD export done.")
    except Exception as e:
        print(f"USD export failed: {{e}} (usd_export may need Blender 4.0+)")

print("=== Blender export script complete ===")
'''
    return script


# ─────────────────────────────────────────────────────────────────────────────
# Blender subprocess runner
# ─────────────────────────────────────────────────────────────────────────────

def _run_blender(
    blender_exec: str,
    script_path: Path,
    output_dir: Path,
) -> Dict[str, Path]:
    """
    Execute Blender in background mode with the given script.
    Falls back to direct bpy import if Blender binary not found.
    """
    cmd = [
        blender_exec,
        "--background",
        "--python", str(script_path),
    ]
    log.info(f"Running Blender: {' '.join(cmd)}")

    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300,
        )
        if proc.returncode != 0:
            log.error(f"Blender stderr:\n{proc.stderr[-3000:]}")
            raise RuntimeError(f"Blender exited with code {proc.returncode}")

        log.info("Blender finished successfully")
        for line in proc.stdout.split("\n"):
            if line.strip():
                log.debug(f"  [blender] {line}")

    except FileNotFoundError:
        log.warning(
            f"Blender executable not found at '{blender_exec}'. "
            "Attempting direct bpy import (requires 'pip install bpy') ..."
        )
        _run_script_direct(script_path)

    # Collect output files
    result: Dict[str, Path] = {}
    for fmt, ext in [("fbx", ".fbx"), ("usd", ".usdc")]:
        p = output_dir / f"head_audio2face{ext}"
        if p.exists():
            result[fmt] = p
            log.info(f"  Output [{fmt.upper()}]: {p}")

    return result


def _run_script_direct(script_path: Path) -> None:
    """Execute the generated script via direct bpy import (standalone bpy)."""
    try:
        import bpy  # noqa
        exec(script_path.read_text(encoding="utf-8"))
    except ImportError:
        raise RuntimeError(
            "Neither Blender binary nor standalone 'bpy' package found.\n"
            "Install via: pip install bpy\n"
            "Or set blender_exec= to your Blender binary path."
        )


# ─────────────────────────────────────────────────────────────────────────────
# Audio2Face compatibility notes
# ─────────────────────────────────────────────────────────────────────────────

AUDIO2FACE_NOTES = """
Audio2Face Compatibility Notes
===============================
1. Import the exported .fbx or .usdc into NVIDIA Audio2Face.
2. In Audio2Face → Setup → BlendShape Solver:
   - Select the mesh: "Head_Mesh"
   - The tool auto-detects shape keys matching ARKit names.
3. Blendshape names follow the ARKit 52-blendshape convention.
   Supported by this pipeline:
   {names}
4. For best results, use the FBX export — Audio2Face 2023.2+ supports
   both FBX and USD.
5. Ensure "Head_Armature / Head" bone exists for head-pose control.
6. To drive lip sync: Audio2Face → Audio → Load WAV, then
   click "Generate" — it maps to the Viseme_* shape keys automatically.
""".format(names="\n   ".join(f"- {n}" for n in BLENDSHAPE_NAMES))


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

def _cli():
    parser = argparse.ArgumentParser(description="Stage 6: Audio2Face Export")
    parser.add_argument("mesh",          help="Retopologised face OBJ")
    parser.add_argument("blendshape_dir",help="Directory with .npy blendshape files")
    parser.add_argument("--output-dir",  default=str(OUTPUTS_DIR))
    parser.add_argument("--formats",     nargs="+", default=["fbx", "usd"],
                        choices=["fbx", "usd"])
    parser.add_argument("--blender",     default="blender",
                        help="Path to Blender executable")
    args = parser.parse_args()

    result = export_for_audio2face(
        mesh_path      = args.mesh,
        blendshape_dir = args.blendshape_dir,
        output_dir     = args.output_dir,
        formats        = args.formats,
        blender_exec   = args.blender,
    )
    log.info("Export complete:")
    for fmt, path in result.items():
        log.info(f"  {fmt.upper()}: {path}")
    print(AUDIO2FACE_NOTES)


if __name__ == "__main__":
    _cli()
